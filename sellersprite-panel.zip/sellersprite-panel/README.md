# SellerSprite Private Label Pazar Analiz Paneli

Web tabanlı panel: ekip keyword yazar → backend SellerSprite MCP'ye bağlanıp
veriyi çeker → panelde gösterir + ortak veritabanına kaydeder. Ekip üyeleri
kendi Claude/MCP kurulumu yapmaz, sadece web panele girer.

## Mimari

```
Web panel (frontend/)  →  Backend (FastAPI, backend/)  →  SellerSprite MCP
                                    ↓
                            SQLite (ortak önbellek + karar geçmişi)
```

- **Backend tek bir SellerSprite key kullanır** (ekip için ayrı key gerekmez).
- Bir keyword bir kez çekilir, 24 saat önbellekte kalır — aynı keyword tekrar
  sorgulanırsa MCP kotası harcanmaz (bkz. `database.py` → `CACHE_TTL_SECONDS`).
- CVR/ACOS/CPA **backend'de hesaplanır** (SellerSprite UI'daki "Conversion
  Rate" ile birebir aynı değildir — farklı metodoloji, bkz. `scoring.py`).

## Kurulum (yerel test)

```bash
cd backend
python -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env   # .env içine gerçek SELLERSPRITE_SECRET_KEY'i yaz
uvicorn main:app --reload
```

Backend `http://localhost:8000` üzerinde çalışır. Frontend'i açmak için:

```bash
cd frontend
python -m http.server 5500
```

Tarayıcıda `http://localhost:5500` — panel `http://localhost:8000`'e istek atar
(CORS zaten `main.py`'de açık).

## Railway'e deploy

1. Bu `backend/` klasörünü ayrı bir GitHub repo'suna koy (ya da mono-repo'da
   Railway'in "root directory" ayarını `backend/` yap).
2. Railway → New Project → Deploy from GitHub.
3. Environment Variables'a `SELLERSPRITE_SECRET_KEY` ekle.
4. Railway otomatik `Procfile`'ı okur, `uvicorn main:app` ile başlar.
5. Frontend'i Railway'in static hosting'ine, Vercel'e veya mevcut Güzel
   Hosting alanına koy; `frontend/app.js` içindeki `API_BASE` sabitine
   backend'in gerçek URL'ini yaz (örn. `https://pl-panel-api.up.railway.app`).

## ÖNEMLİ — Bu kod deploy edilmeden test edilmedi

Bu ortamda (Claude'un sandbox'ı) SellerSprite MCP sunucusuna doğrudan ağ
erişimi yok — sadece paket registry'lerine (pypi, npm, github) erişim var.
Yani bu backend kodu **gerçek bir MCP bağlantısıyla uçtan uca çalıştırılıp
doğrulanamadı.** Söylenebilecek kesin şey: (1) tüm tool adları ve temel
davranışlar (`returnFields` sorunu, kategori node akışı, keyword_miner
alanları) Claude Desktop üzerinden gerçek çağrılarla test edildi ve
`mcp_client.py`/`main.py` bunları birebir yansıtıyor; (2) Python syntax'ı ve
import bütünlüğü doğrulandı. İlk gerçek deploy sonrası olası noktalar:

- `product_node` çıktısının tam JSON şekli (`main.py` → `resolve_category_node`)
  — tool_search sırasında gördüğümüz şemaya göre yazıldı ama alan adlarında
  küçük sapma olabilir.
- `market_brand_concentration` / `price_distribution` / `launch_date_distribution`
  içindeki liste alanının tam adı (`data.items` mi, `items` mi) — frontend'de
  her ikisini de deneyen esnek parsing var (`app.js` → `drawPriceChart` vb.)
  ama backend tarafında da aynı esnekliği eklemek gerekebilir.
- MCP Python SDK'sının (`mcp` paketi) `streamablehttp_client` fonksiyon imzası
  sürüm güncellemeleriyle değişmiş olabilir — `requirements.txt`'teki
  `mcp==1.2.0` sabitlendi, farklı bir sürüm gerekirse dokümantasyonu kontrol et.

İlk deploy sonrası `/api/analyze` çağrısını gerçek bir keyword'le deneyip
dönen hata/veri şeklini birlikte incelemek en hızlı doğrulama yolu olur.

## API Uçları

| Uç | Açıklama |
|---|---|
| `POST /api/analyze` | Ana analiz — keyword + market alır, tam paneli döndürür |
| `POST /api/competitors` | ASIN listesi verilince gerçek satış/ciro/BSR çeker |
| `POST /api/profit` | Kar analizi hesaplar (CVR/ACOS girdisiyle) |
| `POST /api/decision` | Ekibin Uygun/Sınırda/Elenmiş kararını kaydeder |
| `GET /api/recent` | Son analiz edilen keyword'lerin listesi |
| `GET /api/thresholds` | Ön değerlendirme eşik değerleri |

## Ön değerlendirme eşikleri (scoring.py)

0 olumsuz → **Uygun** · 1-3 olumsuz → **Sınırda** · 4+ olumsuz → **Elenmiş**
(tek bir olumsuz kriter tek başına elemez).

---

## HERCULES SIGNAL ENGINE & QIPO v2.1 — entegrasyon (2026-07-09)

Backend'e Hercules tasarım dokümanı (v2.1) birebir entegre edildi. Yeni modüller:

| Dosya | İçerik | Test durumu |
|---|---|---|
| `signal_engine.py` | Market/Demand/Truth/Risk/Proof sinyalleri, Opportunity Score, Blue Ocean rozeti, Stage 1 kapısı, compliance veto | ✅ Gerçek MCP verisiyle (samsung water filter) test edildi |
| `bayesian.py` | Beta(α,β) prior + event-bazlı güncelleme + p̂ + %10-90 kredi aralığı (scipy) | ✅ Çok-adımlı senaryo ile test edildi |
| `portfolio.py` | QIPO — CP-SAT (OR-Tools) exact solver, bütçe/kategori/tedarikçi kısıtları, ikili ceza/bonus | ✅ 5 adaylı gerçek senaryoyla test edildi (<3ms, kanıtlanmış optimum) |

Yeni API uçları: `/api/signals`, `/api/proof-assets` (+ approve/list), `/api/compliance-check`,
`/api/portfolio/solve` (+ `/api/portfolio/{run_id}` polling), `/api/learning-event`, `/api/learning/{keyword}`.

**Test yöntemi ve sınırı:** `signal_engine.py`, `bayesian.py`, `portfolio.py` saf Python/matematik
olduğu için bu ortamda **gerçekten çalıştırıldı ve doğrulandı** (gerçek girdilerle, gerçek çıktılar
üretildi — bkz. yukarıdaki tablo). `main.py`'deki yeni endpoint'ler de FastAPI TestClient ile
gerçek HTTP istekleriyle test edildi (SellerSprite MCP bağlantısı olmadan, sahte/stub bir `mcp`
modülüyle — yani endpoint routing/validation/DB katmanı doğrulandı, gerçek MCP veri akışı değil).

### Dokümandan sapmalar / netleştirilmesi gerekenler (dürüstçe işaretli)

1. **Demand (§2.3) ve Truth (§2.4) sinyalleri için doküman iç ağırlık vermiyor** — yalnızca
   bileşen listesi var. `signal_engine.py` içinde makul VARSAYIM ağırlıklar kullanıldı, kod içinde
   `"VARSAYIM"` yorumlarıyla işaretli. Doküman kuralı gereği ("20-30 döngüye kadar manuel sabit")
   bu ağırlıklar ekiple birlikte gözden geçirilip kalibre edilmeli.

2. **Stage 1 Gate eşik çelişkisi:** Doküman "OpportunityScore ≥ 60 VE mevcut eşik kuralları
   (0 olumsuz)" diyor. Ancak ekip daha önce ön değerlendirme eşiğini **"4+ olumsuz = Elenmiş"**
   olacak şekilde değiştirmişti (`scoring.py::ELIMINATE_AT`). `signal_engine.py::stage1_gate()`
   bu çelişkiyi "team_verdict != 'Elenmiş'" olarak yorumlayıp ekip eşiğiyle tutarlı tuttu — ama bu
   bir **tasarım kararıdır, doküman yazarına danışılmadan alındı**. Netleştirilmeli.

3. **Risk Signal'in alt bileşenleri (regulation_risk, ip_trademark_risk vb.) otomatik
   hesaplanmıyor** — şu an manuel/heuristik girdi olarak `/api/signals` çağrısına parametre
   geçiliyor. Gerçek bir regülasyon/IP-risk tespit motoru (örn. trademark_list MCP tool'uyla
   otomatik IP riski hesaplama) ayrı bir geliştirme gerektirir.

4. **QIPO'nun `v_i` (aday değeri) ve `c_i` (maliyet) girdileri dışarıdan verilir** — yani
   "OpportunityScore × beklenen aylık net kar" hesaplaması şu an backend'de otomatik
   bağlanmıyor; `/api/portfolio/solve` çağrısını yapan taraf (frontend ya da ayrı bir orkestrasyon
   script'i) bu değerleri `/api/signals` ve kar analizinden hesaplayıp Candidate olarak geçmeli.

5. **Async gerekçe üretimi (§3.4) `ANTHROPIC_API_KEY` gerektirir** — kullanıcının kendi Anthropic
   API key'i olmadan bu özellik `explanation_status: "failed"` döner (sessizce başarısız olmaz,
   açıkça işaretlenir — doküman kuralına uygun: "sessiz düşük kalite fallback yok").

6. **category_cert_requirements tablosu Hydrelon gamı için başlangıç kayıtlarıyla seed edildi**
   (§2.7 örnek belge adları) — doküman açıkça "belge adları örnektir, danışman onayı gerekir"
   diyor; production'a geçmeden önce gerçek belge gereksinimleri danışmanla doğrulanmalı.

### Henüz yapılmayanlar

- Frontend'e Signal Engine / Portfolio / Learning görünümleri eklenmedi (şu an yalnızca backend
  API'leri hazır). Bir sonraki adım bunları panelde göstermek.
- Next.js + Supabase Realtime (dokümanın orijinal önerisi) yerine tek FastAPI servisi +
  BackgroundTasks + polling kullanıldı — ekibin mevcut stack'i (FastAPI+SQLite+Railway) ile
  tutarlı olması için bilinçli bir sadeleştirme.
